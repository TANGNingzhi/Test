package xyz.chengzi.halma.controller;

import xyz.chengzi.halma.listener.InputListener;
import xyz.chengzi.halma.model.ChessBoard;
import xyz.chengzi.halma.model.ChessBoardLocation;
import xyz.chengzi.halma.model.ChessPiece;
import xyz.chengzi.halma.view.ChessBoardComponent;
import xyz.chengzi.halma.view.ChessComponent;
import xyz.chengzi.halma.view.SquareComponent;
import xyz.chengzi.halma.view.victoryMusic;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.zip.GZIPOutputStream;

public class PlayWithMachine implements InputListener {
    private ChessBoardComponent view;
    private ChessBoard model;

    private ChessBoardLocation selectedLocation;
    private Color currentPlayer;
    private Color canMoveColor;
    private JLabel thisplayer;
    private int[][] camp;
    private int[][] situation;
    private boolean[][] canMove = new boolean[16][16];
    private ChessBoardLocation i1 = null,
            i2 = null,
            f1 = null,
            f2 = null;

    public PlayWithMachine(ChessBoardComponent chessBoardComponent, ChessBoard chessBoard) {
        this.view = chessBoardComponent;
        this.model = chessBoard;
        view.registerListener(this);
        model.registerListener(view);
        model.placeInitialPieces2();
        currentPlayer = ChessBoard.getChessColor1();
        camp = new int[chessBoard.getDimension()][chessBoard.getDimension()];
        situation = new int[chessBoard.getDimension()][chessBoard.getDimension()];
        for (int i = 0; i < chessBoard.getDimension() ; i++) {
            for (int j = 0; j < chessBoard.getDimension() ; j++) {
                camp[i][j] = 0;
            }
        }
        for (int i = 0; i < 16; i ++){
            for (int j = 0; j < 16; j ++){
                canMove[i][j] = false;
            }
        }
        for (int i = 0; i <= 5; i ++) {
            for (int j = 0; j <= 5 - i; j ++) {
                camp[i][j] = 3;
                camp[chessBoard.getDimension() - i - 1][chessBoard.getDimension() - j - 1] = 1;
            }
        }
        camp[0][5] = 0; camp[5][0] = 0;
        camp[chessBoard.getDimension() - 1][chessBoard.getDimension() - 6] = 0;
        camp[chessBoard.getDimension() - 6][chessBoard.getDimension() - 1] = 0;
        for (int i = 0; i < chessBoard.getDimension(); i++){
            for (int j = 0; j < chessBoard.getDimension(); j++){
                if (chessBoard.getChessPieceAt(new ChessBoardLocation(i,j)) == null){
                    situation[i][j] = 0;
                }else{
                    Color currentColor = chessBoard.getChessPieceAt(new ChessBoardLocation(i,j)).getColor();
                    situation[i][j] = (currentColor == ChessBoard.getChessColor3()) ? 3 : 1;
                }
            }
        }
    }

    public void resetCanMove(){
        for (int i = 0; i < 16; i ++){
            for (int j = 0; j < 16; j ++){
                canMove[i][j] = false;
            }
        }
    }

    public boolean[][] getCanMove() {
        return canMove;
    }

    public Color getCurrentPlayer() {
        return currentPlayer;
    }

    public void reStartGame2() {
        model.placeInitialPieces2();
        this.currentPlayer = ChessBoard.getChessColor1();
        thisplayer.setText("Player turn: VIOLET");
    }

    public void setThisplayer(JLabel thisplayer) {
        this.thisplayer = thisplayer;
    }

    public ChessBoardLocation getSelectedLocation() {
        return selectedLocation;
    }

    public void setSelectedLocation(ChessBoardLocation location) {
        this.selectedLocation = location;
    }

    public void resetSelectedLocation() {
        setSelectedLocation(null);
    }

    public boolean hasSelectedLocation() {
        return selectedLocation != null;
    }

    public boolean couldMove(ChessBoardLocation x){
        ChessBoardLocation x1 = new ChessBoardLocation(x.getRow() + 1, x.getColumn() + 1);
        ChessBoardLocation x2 = new ChessBoardLocation(x.getRow(), x.getColumn() + 1);
        ChessBoardLocation x3 = new ChessBoardLocation(x.getRow() + 1, x.getColumn());
        return ((model.isValidMove(x,x1)) || (model.isValidMove(x,x2)) || (model.isValidMove(x,x3)));
    }

    public void machineMove(ChessBoardLocation x) {
        i2 = x;
        ChessBoardLocation Ta1 = new ChessBoardLocation(x.getRow() + 1, x.getColumn() + 1);
        if (model.isValidMove(x,Ta1)) {
            model.moveChessPiece(x, Ta1);
        }
        else {
            Ta1 = new ChessBoardLocation(x.getRow(),x.getColumn() + 1);
            if (model.isValidMove(x,Ta1)) {
                model.moveChessPiece(x, Ta1);
            } else {
                Ta1 = new ChessBoardLocation(x.getRow() + 1,x.getColumn());
                if (model.isValidMove(x,Ta1)) model.moveChessPiece(x, Ta1);
            }
        }
        f2 = Ta1;
    }

    public Color nextPlayer() {
        ChessBoardLocation Ta = null;
        boolean judge = false;
        for (int i = 0; i < 16; i ++){
            for (int j = 0; j < 16; j ++){
                Ta = new ChessBoardLocation(i,j);
                if (model.getChessPieceAt(Ta) != null){
                    if ((model.getChessPieceAt(Ta).getColor() == ChessBoard.getChessColor3()) && (couldMove(Ta))){
                        judge = true;
                        break;
                    }
                }
            }
            if (judge) break;
        }
        if ((judge) && (couldMove(Ta))) machineMove(Ta);
        thisplayer.setText("Player turn: VIOLET");
        return currentPlayer = ChessBoard.getChessColor1();
    }

    @Override
    public void onPlayerClickSquare(ChessBoardLocation location, SquareComponent component) {
        boolean judge = true;
        if (hasSelectedLocation()){
            int initialRow = getSelectedLocation().getRow();
            int initialCol = getSelectedLocation().getColumn();
            int finalRow = location.getRow();
            int finalCol = location.getColumn();
            if ((model.getChessPieceAt(getSelectedLocation()).getColor() == ChessBoard.getChessColor3())
                    && (camp[initialRow][initialCol] == 1)){
                judge = camp[finalRow][finalCol] == 1;
            }
            if ((model.getChessPieceAt(getSelectedLocation()).getColor() == ChessBoard.getChessColor1())
                    && (camp[initialRow][initialCol] == 3)){
                judge = camp[finalRow][finalCol] == 3;
            }
        }
        if (hasSelectedLocation() && model.isValidMove(getSelectedLocation(), location) && judge) {
            i1 = selectedLocation; f1 = location;
            int count3 = 0; int count1 = 0;
            model.moveChessPiece(selectedLocation, location);
            resetSelectedLocation();
            resetCanMove();
            for (int i = 0; i < model.getDimension(); i++){
                for (int j = 0; j < model.getDimension(); j++){
                    if (model.getChessPieceAt(new ChessBoardLocation(i,j)) == null){
                        situation[i][j] = 0;
                    }else{
                        Color currentColor = model.getChessPieceAt(new ChessBoardLocation(i,j)).getColor();
                        situation[i][j] = (currentColor == ChessBoard.getChessColor3()) ? 3 : 1;
                    }
                    if ((situation[i][j] == 3) && (camp[i][j] == 1)) count3 ++;
                    if ((situation[i][j] == 1) && (camp[i][j] == 3)) count1 ++;
                }
            }
            nextPlayer();
            if ((PlayWithMachine.this.isWinner() == 1) || (PlayWithMachine.this.isWinner() == 3)) {
                JFrame jf = new JFrame();
                jf.setSize(300,100);
                if (PlayWithMachine.this.isWinner() == 1) {
                    JLabel jl = new JLabel("VIOLET Victory!",JLabel.CENTER);
                    currentPlayer = ChessBoard.getChessColor1();
                    jf.add(jl);
                    victoryMusic vm = new victoryMusic();
                    vm.play();
                    thisplayer.setText("Game Over");
                }
                if (PlayWithMachine.this.isWinner() == 3) {
                    JLabel jl = new JLabel("RED Victory!",JLabel.CENTER);
                    currentPlayer = ChessBoard.getChessColor3();
                    jf.add(jl);
                    victoryMusic vm = new victoryMusic();
                    vm.play();
                    thisplayer.setText("Game Over");
                }

                jf.setLocation(620,300);
                jf.setVisible(true);
            }
            else {
                ChessBoardLocation p = null,q = null;
                JFrame jf = new JFrame();
                jf.setSize(300,100);
                if (model.getChessPieceAt(location) != null) {
                    if ((model.getChessPieceAt(location).getColor() == ChessBoard.getChessColor1()) && (count1 == 18)){
                        for (int i = 0; i < 16; i ++) {
                            for (int j = 0; j < 16; j ++){
                                if ((camp[i][j] == 3) && (situation[i][j] == 0)) p = new ChessBoardLocation(i,j);
                                if ((camp[i][j] == 0) && (situation[i][j] == 1)) q = new ChessBoardLocation(i,j);
                            }
                        }
                        if ((p != null) && (q != null) && (model.isValidMove(q,p))) {
                            JLabel jl = new JLabel("Violet is about to win!",JLabel.CENTER);
                            jf.add(jl);
                            jf.setLocation(620,300);
                            jf.setVisible(true);
                        }
                    }
                    if ((model.getChessPieceAt(location).getColor() == ChessBoard.getChessColor3()) && (count3 == 18)){
                        for (int i = 0; i < 16; i ++) {
                            for (int j = 0; j < 16; j ++){
                                if ((camp[i][j] == 1) && (situation[i][j] == 0)) p = new ChessBoardLocation(i,j);
                                if ((camp[i][j] == 0) && (situation[i][j] == 3)) q = new ChessBoardLocation(i,j);
                            }
                        }
                        if ((p != null) && (q != null) && (model.isValidMove(q,p))) {
                            JLabel jl = new JLabel("Red is about to win!",JLabel.CENTER);
                            jf.add(jl);
                            jf.setLocation(620,300);
                            jf.setVisible(true);
                        }
                    }
                }
            }
        }
    }

    public void undo(){
        if ((i1 != null) && (i2 != null) && (f1 != null) && (f2 != null)){
            model.moveChessPiece(f2,i2);
            model.moveChessPiece(f1,i1);
            i1 = null; i2 = null; f1 = null; f2 = null;
            resetSelectedLocation();
        }
    }

    @Override
    public void onPlayerClickChessPiece(ChessBoardLocation location, ChessComponent component) {
        ChessPiece piece = model.getChessPieceAt(location);
        if (piece.getColor() == currentPlayer && (!hasSelectedLocation() || location.equals(getSelectedLocation()))) {
            if (!hasSelectedLocation()) {
                setSelectedLocation(location);
                canMoveColor = model.getChessPieceAt(location).getColor();
                for (int i = 0; i < 16; i ++){
                    for (int j = 0; j < 16; j ++){
                        ChessBoardLocation theLocation = new ChessBoardLocation(i,j);
                        if (model.isValidMove(location,theLocation)){
                            boolean judge = true;
                            int initialRow = location.getRow();
                            int initialCol = location.getColumn();
                            if ((model.getChessPieceAt(location).getColor() == ChessBoard.getChessColor3())
                                    && (camp[initialRow][initialCol] == 1)){
                                judge = camp[i][j] == 1;
                            }
                            if ((model.getChessPieceAt(location).getColor() == ChessBoard.getChessColor1())
                                    && (camp[initialRow][initialCol] == 3)){
                                judge = camp[i][j] == 3;
                            }
                            if (judge) canMove[i][j] = true;
                        }
                    }
                }
            } else {
                resetSelectedLocation();
                resetCanMove();
            }
            component.setSelected(!component.isSelected());
            component.repaint();
        }
    }

    public int isWinner(){
        boolean Player1 = true;
        boolean Player3 = true;
        for (int row = 0; row < model.getDimension(); row++){
            for (int col = 0; col < model.getDimension(); col++){
                if (camp[row][col] == 1){
                    Player3 = false;
                    if (model.getChessPieceAt(new ChessBoardLocation(row,col)) != null) {
                        Color currentColor = model.getChessPieceAt(new ChessBoardLocation(row,col)).getColor();
                        Player3 = (currentColor == ChessBoard.getChessColor3());
                    }
                }
                if (!Player3) break;
            }
            if (!Player3) break;
        }
        for (int row = 0; row < model.getDimension(); row++){
            for (int col = 0; col < model.getDimension(); col++){
                if (camp[row][col] == 3) {
                    Player1 = false;
                    if (model.getChessPieceAt(new ChessBoardLocation(row,col)) != null) {
                        Color currentColor = model.getChessPieceAt(new ChessBoardLocation(row,col)).getColor();
                        Player1 = (currentColor == ChessBoard.getChessColor1());
                    }
                }
                if (!Player1) break;
            }
            if (!Player1) break;
        }
        if ((Player1) && (Player3)) return -1;
        if (Player1) return 1;
        if (Player3) return 3;
        return 0;
    }

    public int[][] getSituation() {
        return situation;
    }

    public Color getCanMoveColor() {
        return canMoveColor;
    }
}
