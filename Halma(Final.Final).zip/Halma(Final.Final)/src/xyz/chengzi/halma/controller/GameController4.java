package xyz.chengzi.halma.controller;

import xyz.chengzi.halma.listener.InputListener;
import xyz.chengzi.halma.model.ChessBoard;
import xyz.chengzi.halma.model.ChessBoardLocation;
import xyz.chengzi.halma.model.ChessPiece;
import xyz.chengzi.halma.view.ChessBoardComponent;
import xyz.chengzi.halma.view.ChessComponent;
import xyz.chengzi.halma.view.SquareComponent;
import xyz.chengzi.halma.view.victoryMusic;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class GameController4 implements InputListener {
    private ChessBoardComponent view;
    private ChessBoard model;

    private ChessBoardLocation selectedLocation;
    private Color currentPlayer;
    private Color canMoveColor = null;
    private JLabel thisplayer;
    private int[][] camp;
    private int[][] situation;
    private boolean[][] canMove = new boolean[16][16];
    private ArrayList<ChessBoardLocation> initialLocation = new ArrayList<>();
    private ArrayList<ChessBoardLocation> finalLocation = new ArrayList<>();
    private ChessBoardLocation[] i = new ChessBoardLocation[4],
            f = new ChessBoardLocation[4];

    public GameController4(ChessBoardComponent chessBoardComponent, ChessBoard chessBoard) {
        this.view = chessBoardComponent;
        this.model = chessBoard;
        view.registerListener(this);
        model.registerListener(view);
        model.placeInitialPieces4();
        for (int k = 0; k < 4; k ++){
            i[k] = null;
            f[k] = null;
        }
        int n = (int) (4 * Math.random());
        if (n == 0){
            this.currentPlayer = ChessBoard.getChessColor1();
        }else if (n == 1){
            this.currentPlayer = ChessBoard.getChessColor2();
        }else if (n == 2){
            this.currentPlayer = ChessBoard.getChessColor3();
        }else {
            this.currentPlayer = ChessBoard.getChessColor4();
        }
        camp = new int[chessBoard.getDimension()][chessBoard.getDimension()];
        situation = new int[chessBoard.getDimension()][chessBoard.getDimension()];
        for (int i = 0; i < chessBoard.getDimension() ; i++) {
            for (int j = 0; j < chessBoard.getDimension() ; j++) {
                camp[i][j] = 0;
            }
        }
        for (int i = 0; i < 16; i ++){
            for (int j = 0; j < 16; j ++){
                canMove[i][j] = false;
            }
        }
        for (int i = 0; i <= 4; i ++) {
            for (int j = 0; j <= 4 - i; j ++) {
                camp[i][j] = 3;
                camp[chessBoard.getDimension() - i - 1][chessBoard.getDimension() - j - 1] = 1;
                camp[i][chessBoard.getDimension() - j - 1] = 2;
                camp[chessBoard.getDimension() - i - 1][j] = 4;
            }
        }
        camp[0][4] = 0;  camp[4][0] = 0;
        camp[chessBoard.getDimension() - 1][chessBoard.getDimension() - 5] = 0;
        camp[chessBoard.getDimension() - 5][chessBoard.getDimension() - 1] = 0;
        camp[0][chessBoard.getDimension() - 5] = 0;
        camp[4][chessBoard.getDimension() - 1] = 0;
        camp[chessBoard.getDimension() - 1][4] = 0;
        camp[chessBoard.getDimension() - 5][0] = 0;
        for (int i = 0; i < chessBoard.getDimension(); i++){
            for (int j = 0; j < chessBoard.getDimension(); j++){
                if (chessBoard.getChessPieceAt(new ChessBoardLocation(i,j)) == null){
                    this.situation[i][j] = 0;
                }else{
                    Color currentColor = chessBoard.getChessPieceAt(new ChessBoardLocation(i,j)).getColor();
                    if (currentColor == ChessBoard.getChessColor1()) this.situation[i][j] = 1;
                    else if (currentColor == ChessBoard.getChessColor2()) this.situation[i][j] = 2;
                    else if (currentColor == ChessBoard.getChessColor3()) this.situation[i][j] = 3;
                    else this.situation[i][j] = 4;
                }
            }
        }
    }

    public GameController4(ChessBoardComponent chessBoardComponent, ChessBoard chessBoard, int[][] situation, int c) {
        this.view = chessBoardComponent;
        this.model = chessBoard;
        if (c == 1) this.currentPlayer = ChessBoard.getChessColor1();
        else if (c == 2) this.currentPlayer = ChessBoard.getChessColor2();
        else if (c == 3) this.currentPlayer = ChessBoard.getChessColor3();
        else this.currentPlayer = ChessBoard.getChessColor4();
        for (int k = 0; k < 4; k ++){
            i[k] = null;
            f[k] = null;
        }
        view.registerListener(this);
        model.registerListener(view);
        model.placeInitialPieces4(situation);
        view.onChessBoardReload(model);
        camp = new int[chessBoard.getDimension()][chessBoard.getDimension()];
        this.situation = new int[chessBoard.getDimension()][chessBoard.getDimension()];
        for (int i = 0; i < chessBoard.getDimension() ; i++) {
            for (int j = 0; j < chessBoard.getDimension() ; j++) {
                camp[i][j] = 0;
            }
        }
        for (int i = 0; i < 16; i ++){
            for (int j = 0; j < 16; j ++){
                canMove[i][j] = false;
            }
        }
        for (int i = 0; i <= 4; i ++) {
            for (int j = 0; j <= 4 - i; j ++) {
                camp[i][j] = 3;
                camp[chessBoard.getDimension() - i - 1][chessBoard.getDimension() - j - 1] = 1;
                camp[i][chessBoard.getDimension() - j - 1] = 2;
                camp[chessBoard.getDimension() - i - 1][j] = 4;
            }
        }
        camp[0][4] = 0;  camp[4][0] = 0;
        camp[chessBoard.getDimension() - 1][chessBoard.getDimension() - 5] = 0;
        camp[chessBoard.getDimension() - 5][chessBoard.getDimension() - 1] = 0;
        camp[0][chessBoard.getDimension() - 5] = 0;
        camp[4][chessBoard.getDimension() - 1] = 0;
        camp[chessBoard.getDimension() - 1][4] = 0;
        camp[chessBoard.getDimension() - 5][0] = 0;
        for (int i = 0; i < chessBoard.getDimension(); i++){
            for (int j = 0; j < chessBoard.getDimension(); j++){
                if (chessBoard.getChessPieceAt(new ChessBoardLocation(i,j)) == null){
                    this.situation[i][j] = 0;
                }else{
                    Color currentColor = chessBoard.getChessPieceAt(new ChessBoardLocation(i,j)).getColor();
                    if (currentColor == ChessBoard.getChessColor1()) this.situation[i][j] = 1;
                    else if (currentColor == ChessBoard.getChessColor2()) this.situation[i][j] = 2;
                    else if (currentColor == ChessBoard.getChessColor3()) this.situation[i][j] = 3;
                    else this.situation[i][j] = 4;
                }
            }
        }
    }

    public void resetCanMove(){
        for (int i = 0; i < 16; i ++){
            for (int j = 0; j < 16; j ++){
                canMove[i][j] = false;
            }
        }
    }

    public boolean[][] getCanMove() {
        return canMove;
    }

    public Color getCanMoveColor() {
        return canMoveColor;
    }

    public Color getCurrentPlayer() {
        return currentPlayer;
    }

    public int[][] getSituation() {
        return situation;
    }

    public void restartgame4() {
        model.placeInitialPieces4();
        initialLocation.clear();
        finalLocation.clear();
        int n = (int) (4 * Math.random());
        if (n == 0){
            this.currentPlayer = ChessBoard.getChessColor1();
            thisplayer.setText("Player turn: VIOLET");
        }else if (n == 1){
            this.currentPlayer = ChessBoard.getChessColor2();
            thisplayer.setText("Player turn: GREEN");
        }else if (n == 2){
            this.currentPlayer = ChessBoard.getChessColor3();
            thisplayer.setText("Player turn: RED");
        }else {
            this.currentPlayer = ChessBoard.getChessColor4();
            thisplayer.setText("Player turn: YELLOW");
        }

    }

    public void setThisplayer(JLabel thisplayer) {
        this.thisplayer = thisplayer;
    }

    public ChessBoardLocation getSelectedLocation() {
        return selectedLocation;
    }

    public void setSelectedLocation(ChessBoardLocation location) {
        this.selectedLocation = location;
    }

    public void resetSelectedLocation() {
        setSelectedLocation(null);
    }

    public boolean hasSelectedLocation() {
        return selectedLocation != null;
    }

    public Color nextPlayer() {
        if (currentPlayer == ChessBoard.getChessColor4()) {
            thisplayer.setText("Player turn: VIOLET");
            return currentPlayer = ChessBoard.getChessColor1();
        }
        if (currentPlayer == ChessBoard.getChessColor1()) {
            thisplayer.setText("Player turn: GREEN");
            return currentPlayer = ChessBoard.getChessColor2();
        }
        if (currentPlayer == ChessBoard.getChessColor2()) {
            thisplayer.setText("Player turn: RED");
            return currentPlayer = ChessBoard.getChessColor3();
        }
        if (currentPlayer == ChessBoard.getChessColor3()) {
            thisplayer.setText("Player turn: YELLOW");
            return currentPlayer = ChessBoard.getChessColor4();
        }
        return currentPlayer;
    }

    @Override
    public void onPlayerClickSquare(ChessBoardLocation location, SquareComponent component) {
        boolean judge = true;
        if (hasSelectedLocation()){
            int initialRow = getSelectedLocation().getRow();
            int initialCol = getSelectedLocation().getColumn();
            int finalRow = location.getRow();
            int finalCol = location.getColumn();
            if ((model.getChessPieceAt(getSelectedLocation()).getColor() == ChessBoard.getChessColor3())
                    && ((camp[initialRow][initialCol] == 1))){
                judge = camp[finalRow][finalCol] == camp[initialRow][initialCol];
            }
            if ((model.getChessPieceAt(getSelectedLocation()).getColor() == ChessBoard.getChessColor1())
                    && ((camp[initialRow][initialCol] == 3))){
                judge = camp[finalRow][finalCol] == camp[initialRow][initialCol];
            }
            if ((model.getChessPieceAt(getSelectedLocation()).getColor() == ChessBoard.getChessColor2())
                    && ((camp[initialRow][initialCol] == 4))){
                judge = camp[finalRow][finalCol] == camp[initialRow][initialCol];
            }
            if ((model.getChessPieceAt(getSelectedLocation()).getColor() == ChessBoard.getChessColor4())
                    && ((camp[initialRow][initialCol] == 2))){
                judge = camp[finalRow][finalCol] == camp[initialRow][initialCol];
            }
        }
        if (hasSelectedLocation() && model.isValidMove(getSelectedLocation(), location) && judge) {
            i[0] = i[1]; i[1] = i[2]; i[2] = i[3]; i[3] = selectedLocation;
            f[0] = f[1]; f[1] = f[2]; f[2] = f[3]; f[3] = location;
            int count3 = 0; int count1 = 0;int count2 = 0; int count4 = 0;
            initialLocation.add(getSelectedLocation());
            finalLocation.add(location);
            if (model.getCount() > 0) {
                ArrayList<ChessBoardLocation> jumpList = model.getJumpList();
                Thread t = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        for (int i = jumpList.size() - 1; i > 0; i --){
                            model.moveChessPiece(jumpList.get(i),jumpList.get(i - 1));
                            try {
                                Thread.sleep(500);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                });
                t.start();
            }
            else{
                model.moveChessPiece(selectedLocation, location);
            }
            resetSelectedLocation();
            resetCanMove();
            nextPlayer();
            for (int i = 0; i < model.getDimension(); i++){
                for (int j = 0; j < model.getDimension(); j++){
                    if (model.getChessPieceAt(new ChessBoardLocation(i,j)) == null){
                        situation[i][j] = 0;
                    }else{
                        Color currentColor = model.getChessPieceAt(new ChessBoardLocation(i,j)).getColor();
                        if (currentColor == ChessBoard.getChessColor3()) situation[i][j] = 3;
                        else if (currentColor == ChessBoard.getChessColor1()) situation[i][j] = 1;
                        else if (currentColor == ChessBoard.getChessColor2()) situation[i][j] = 2;
                        else situation[i][j] = 4;
                    }
                    if ((situation[i][j] == 3) && (camp[i][j] == 1)) count3 ++;
                    if ((situation[i][j] == 1) && (camp[i][j] == 3)) count1 ++;
                    if ((situation[i][j] == 2) && (camp[i][j] == 4)) count2 ++;
                    if ((situation[i][j] == 4) && (camp[i][j] == 2)) count4 ++;
                }
            }

            if ((GameController4.this.isWinner() == 1) || (GameController4.this.isWinner() == 2)
                    || (GameController4.this.isWinner() == 3) || (GameController4.this.isWinner() == 4)) {
                JFrame jf = new JFrame();
                jf.setSize(300,100);
                JLabel jl = new JLabel();
                jl.setHorizontalAlignment(JLabel.CENTER);
                jf.setLocation(620,300);
                jf.add(jl);
                jf.setVisible(true);
                if (GameController4.this.isWinner() == 1) {
                    jl.setText("VIOLET Victory!");
                    victoryMusic vm=new victoryMusic();
                    vm.play();
                    thisplayer.setText("Game Over");
                    currentPlayer = ChessBoard.getChessColor1();
                }
                if (GameController4.this.isWinner() == 2) {
                    jl.setText("GREEN Victory!");
                    thisplayer.setText("Game Over");
                    victoryMusic vm=new victoryMusic();
                    vm.play();
                    currentPlayer = ChessBoard.getChessColor2();
                }
                if (GameController4.this.isWinner() == 3) {
                    jl.setText("RED Victory!");
                    thisplayer.setText("Game Over");
                    victoryMusic vm=new victoryMusic();
                    vm.play();
                    currentPlayer = ChessBoard.getChessColor3();
                }
                if (GameController4.this.isWinner() == 4) {
                    jl.setText("YELLOW Victory!");
                    thisplayer.setText("Game Over");
                    victoryMusic vm=new victoryMusic();
                    vm.play();
                    currentPlayer = ChessBoard.getChessColor4();
                }
            }
            else {
                ChessBoardLocation p = null, q = null;
                JFrame jf = new JFrame();
                jf.setSize(300,100);
                if (model.getChessPieceAt(location) != null){
                    if ((model.getChessPieceAt(location).getColor() == ChessBoard.getChessColor1()) && (count1 == 12)){
                        for (int i = 0; i < 16; i ++) {
                            for (int j = 0; j < 16; j ++){
                                if ((camp[i][j] == 3) && (situation[i][j] == 0)) p = new ChessBoardLocation(i,j);
                                if ((camp[i][j] == 0) && (situation[i][j] == 1)) q = new ChessBoardLocation(i,j);
                            }
                        }
                        if ((p != null) && (q != null) && (model.isValidMove(q,p))) {
                            JLabel jl = new JLabel("Violet is about to win!",JLabel.CENTER);
                            jf.add(jl);
                            jf.setLocation(620,300);
                            jf.setVisible(true);
                        }
                    }
                    if ((model.getChessPieceAt(location).getColor() == ChessBoard.getChessColor3()) && (count3 == 12)){
                        for (int i = 0; i < 16; i ++) {
                            for (int j = 0; j < 16; j ++){
                                if ((camp[i][j] == 1) && (situation[i][j] == 0)) p = new ChessBoardLocation(i,j);
                                if ((camp[i][j] == 0) && (situation[i][j] == 3)) q = new ChessBoardLocation(i,j);
                            }
                        }
                        if ((p != null) && (q != null) && (model.isValidMove(q,p))) {
                            JLabel jl = new JLabel("Red is about to win!",JLabel.CENTER);
                            jf.add(jl);
                            jf.setLocation(620,300);
                            jf.setVisible(true);
                        }
                    }
                    if ((model.getChessPieceAt(location).getColor() == ChessBoard.getChessColor2()) && (count2 == 12)){
                        for (int i = 0; i < 16; i ++) {
                            for (int j = 0; j < 16; j ++){
                                if ((camp[i][j] == 4) && (situation[i][j] == 0)) p = new ChessBoardLocation(i,j);
                                if ((camp[i][j] == 0) && (situation[i][j] == 2)) q = new ChessBoardLocation(i,j);
                            }
                        }
                        if ((p != null) && (q != null) && (model.isValidMove(q,p))) {
                            JLabel jl = new JLabel("Green is about to win!",JLabel.CENTER);
                            jf.add(jl);
                            jf.setLocation(620,300);
                            jf.setVisible(true);
                        }
                    }
                    if ((model.getChessPieceAt(location).getColor() == ChessBoard.getChessColor4()) && (count4 == 12)){
                        for (int i = 0; i < 16; i ++) {
                            for (int j = 0; j < 16; j ++){
                                if ((camp[i][j] == 2) && (situation[i][j] == 0)) p = new ChessBoardLocation(i,j);
                                if ((camp[i][j] == 0) && (situation[i][j] == 4)) q = new ChessBoardLocation(i,j);
                            }
                        }
                        if ((p != null) && (q != null) && (model.isValidMove(q,p))) {
                            JLabel jl = new JLabel("Yellow is about to win!",JLabel.CENTER);
                            jf.add(jl);
                            jf.setLocation(620,300);
                            jf.setVisible(true);
                        }
                    }
                }
            }
        }
    }

    @Override
    public void onPlayerClickChessPiece(ChessBoardLocation location, ChessComponent component) {
        ChessPiece piece = model.getChessPieceAt(location);
        if (piece.getColor() == currentPlayer && (!hasSelectedLocation() || location.equals(getSelectedLocation()))) {
            if (!hasSelectedLocation()) {
                setSelectedLocation(location);
                canMoveColor = model.getChessPieceAt(location).getColor();
                for (int i = 0; i < 16; i ++){
                    for (int j = 0; j < 16; j ++){
                        ChessBoardLocation theLocation = new ChessBoardLocation(i,j);
                        if (model.isValidMove(location,theLocation)){
                            boolean judge = true;
                            int initialRow = location.getRow();
                            int initialCol = location.getColumn();
                            if ((model.getChessPieceAt(location).getColor() == ChessBoard.getChessColor3())
                                    && (camp[initialRow][initialCol] == 1)){
                                judge = camp[i][j] == 1;
                            }
                            if ((model.getChessPieceAt(location).getColor() == ChessBoard.getChessColor1())
                                    && (camp[initialRow][initialCol] == 3)){
                                judge = camp[i][j] == 3;
                            }
                            if ((model.getChessPieceAt(location).getColor() == ChessBoard.getChessColor2())
                                    && (camp[initialRow][initialCol] == 4)){
                                judge = camp[i][j] == 4;
                            }
                            if ((model.getChessPieceAt(location).getColor() == ChessBoard.getChessColor4())
                                    && (camp[initialRow][initialCol] == 2)){
                                judge = camp[i][j] == 2;
                            }
                            if (judge) canMove[i][j] = true;
                        }
                    }
                }
            } else {
                resetSelectedLocation();
                resetCanMove();
            }
            component.setSelected(!component.isSelected());
            component.repaint();
        }
    }

    public void playMovingSteps(){
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                model.placeInitialPieces4();
                for (int i = 0; i < initialLocation.size(); i ++){
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    model.moveChessPiece(initialLocation.get(i), finalLocation.get(i));
                }
            }
        });
        t.start();
    }

    public void undo(){
        boolean canUndo = true;
        for (int k = 0; k < 4; k ++){
            if ((i[k] == null) || (f[k] == null)) {
                canUndo = false;
                break;
            }
        }
        if (canUndo){
            for (int k = 3; k >= 0; k --){
                model.moveChessPiece(f[k],i[k]);
                f[k] = null; i[k] = null;
            }
            resetSelectedLocation();
        }
    }

    public int isWinner() {
        boolean Player1 = true;
        boolean Player2 = true;
        boolean Player3 = true;
        boolean Player4 = true;
        for (int row = 0; row < model.getDimension(); row++) {
            for (int col = 0; col < model.getDimension(); col++) {
                if (camp[row][col] == 1) {
                    Player3 = false;
                    if (model.getChessPieceAt(new ChessBoardLocation(row, col)) != null) {
                        Color currentColor = model.getChessPieceAt(new ChessBoardLocation(row, col)).getColor();
                        Player3 = (currentColor == ChessBoard.getChessColor3());
                    }
                }
                if (!Player3) break;
            }
            if (!Player3) break;
        }
        for (int row = 0; row < model.getDimension(); row++) {
            for (int col = 0; col < model.getDimension(); col++) {
                if (camp[row][col] == 3) {
                    Player1 = false;
                    if (model.getChessPieceAt(new ChessBoardLocation(row, col)) != null) {
                        Color currentColor = model.getChessPieceAt(new ChessBoardLocation(row, col)).getColor();
                        Player1 = (currentColor == ChessBoard.getChessColor1());
                    }
                }
                if (!Player1) break;
            }
            if (!Player1) break;
        }
        for (int row = 0; row < model.getDimension(); row++) {
            for (int col = 0; col < model.getDimension(); col++) {
                if (camp[row][col] == 2) {
                    Player4 = false;
                    if (model.getChessPieceAt(new ChessBoardLocation(row, col)) != null) {
                        Color currentColor = model.getChessPieceAt(new ChessBoardLocation(row, col)).getColor();
                        Player4 = (currentColor == ChessBoard.getChessColor4());
                    }
                }
                if (!Player4) break;
            }
            if (!Player4) break;
        }
        for (int row = 0; row < model.getDimension(); row++) {
            for (int col = 0; col < model.getDimension(); col++) {
                if (camp[row][col] == 4) {
                    Player2 = false;
                    if (model.getChessPieceAt(new ChessBoardLocation(row, col)) != null) {
                        Color currentColor = model.getChessPieceAt(new ChessBoardLocation(row, col)).getColor();
                        Player2 = (currentColor == ChessBoard.getChessColor2());
                    }
                }
                if (!Player2) break;
            }
            if (!Player2) break;
        }
        if (Player1) return 1;
        if (Player2) return 2;
        if (Player3) return 3;
        if (Player4) return 4;
        return 0;
    }
}

