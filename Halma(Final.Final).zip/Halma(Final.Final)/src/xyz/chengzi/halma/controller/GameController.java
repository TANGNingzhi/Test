package xyz.chengzi.halma.controller;

import xyz.chengzi.halma.listener.InputListener;
import xyz.chengzi.halma.model.ChessBoard;
import xyz.chengzi.halma.model.ChessBoardLocation;
import xyz.chengzi.halma.model.ChessPiece;
import xyz.chengzi.halma.view.ChessBoardComponent;
import xyz.chengzi.halma.view.ChessComponent;
import xyz.chengzi.halma.view.SquareComponent;
import xyz.chengzi.halma.view.victoryMusic;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class GameController implements InputListener {
    private ChessBoardComponent view;
    private ChessBoard model;

    private ChessBoardLocation selectedLocation;
    private Color currentPlayer;
    private Color canMoveColor = null;
    private JLabel thisplayer;
    private int[][] camp;
    private int[][] situation;
    private boolean[][] canMove = new boolean[16][16];
    private ArrayList<ChessBoardLocation> initialLocation = new ArrayList<>();
    private ArrayList<ChessBoardLocation> finalLocation = new ArrayList<>();
    private ChessBoardLocation i1 = null,
            i2 = null,
            f1 = null,
            f2 = null;

    public GameController(ChessBoardComponent chessBoardComponent, ChessBoard chessBoard) {
        this.view = chessBoardComponent;
        this.model = chessBoard;
        view.registerListener(this);
        model.registerListener(view);
        model.placeInitialPieces2();
        int n = (int) (2 * Math.random());
        if (n == 0){
            this.currentPlayer = ChessBoard.getChessColor3();
        }else{
            this.currentPlayer = ChessBoard.getChessColor1();
        }
        camp = new int[chessBoard.getDimension()][chessBoard.getDimension()];
        situation = new int[chessBoard.getDimension()][chessBoard.getDimension()];
        for (int i = 0; i < chessBoard.getDimension() ; i++) {
            for (int j = 0; j < chessBoard.getDimension() ; j++) {
                camp[i][j] = 0;
            }
        }
        for (int i = 0; i < 16; i ++){
            for (int j = 0; j < 16; j ++){
                canMove[i][j] = false;
            }
        }
        for (int i = 0; i <= 5; i ++) {
            for (int j = 0; j <= 5 - i; j ++) {
                camp[i][j] = 3;
                camp[chessBoard.getDimension() - i - 1][chessBoard.getDimension() - j - 1] = 1;
            }
        }
        camp[0][5] = 0; camp[5][0] = 0;
        camp[chessBoard.getDimension() - 1][chessBoard.getDimension() - 6] = 0;
        camp[chessBoard.getDimension() - 6][chessBoard.getDimension() - 1] = 0;
        for (int i = 0; i < chessBoard.getDimension(); i++){
            for (int j = 0; j < chessBoard.getDimension(); j++){
                if (chessBoard.getChessPieceAt(new ChessBoardLocation(i,j)) == null){
                    situation[i][j] = 0;
                }else{
                    Color currentColor = chessBoard.getChessPieceAt(new ChessBoardLocation(i,j)).getColor();
                    situation[i][j] = (currentColor == ChessBoard.getChessColor3()) ? 3 : 1;
                }
            }
        }
    }

    public GameController(ChessBoardComponent chessBoardComponent, ChessBoard chessBoard, int[][] situation, int c) {
        this.view = chessBoardComponent;
        this.model = chessBoard;
        model.placeInitialPieces2(situation);
        view.registerListener(this);
        model.registerListener(view);
        view.onChessBoardReload(model);
        this.currentPlayer = (c == 3) ? ChessBoard.getChessColor3() : ChessBoard.getChessColor1();
        camp = new int[chessBoard.getDimension()][chessBoard.getDimension()];
        this.situation = new int[chessBoard.getDimension()][chessBoard.getDimension()];
        for (int i = 0; i < chessBoard.getDimension() ; i++) {
            for (int j = 0; j < chessBoard.getDimension() ; j++) {
                camp[i][j] = 0;
            }
        }
        for (int i = 0; i <= 5; i ++) {
            for (int j = 0; j <= 5 - i; j ++) {
                camp[i][j] = 3;
                camp[chessBoard.getDimension() - i - 1][chessBoard.getDimension() - j - 1] = 1;
            }
        }
        for (int i = 0; i < 16; i ++){
            for (int j = 0; j < 16; j ++){
                canMove[i][j] = false;
            }
        }
        camp[0][5] = 0; camp[5][0] = 0;
        camp[chessBoard.getDimension() - 1][chessBoard.getDimension() - 6] = 0;
        camp[chessBoard.getDimension() - 6][chessBoard.getDimension() - 1] = 0;
        for (int i = 0; i < chessBoard.getDimension(); i++){
            for (int j = 0; j < chessBoard.getDimension(); j++){
                if (chessBoard.getChessPieceAt(new ChessBoardLocation(i,j)) == null){
                    this.situation[i][j] = 0;
                }else{
                    Color currentColor = chessBoard.getChessPieceAt(new ChessBoardLocation(i,j)).getColor();
                    this.situation[i][j] = (currentColor == ChessBoard.getChessColor3()) ? 3 : 1;
                }
            }
        }
    }

    public void resetCanMove(){
        for (int i = 0; i < 16; i ++){
            for (int j = 0; j < 16; j ++){
                canMove[i][j] = false;
            }
        }
    }

    public boolean[][] getCanMove() {
        return canMove;
    }

    public Color getCurrentPlayer() {
        return currentPlayer;
    }

    public void reStartGame2() {
        model.placeInitialPieces2();
        initialLocation.clear();
        finalLocation.clear();
        int n = (int) (2 * Math.random());
        if (n == 0){
            this.currentPlayer = ChessBoard.getChessColor3();
            thisplayer.setText("Player turn: RED");
        }else{
            this.currentPlayer = ChessBoard.getChessColor1();
            thisplayer.setText("Player turn: VIOLET");
        }
    }

    public void setThisplayer(JLabel thisplayer) {
        this.thisplayer = thisplayer;
    }

    public ChessBoardLocation getSelectedLocation() {
        return selectedLocation;
    }

    public void setSelectedLocation(ChessBoardLocation location) {
        this.selectedLocation = location;
    }

    public void resetSelectedLocation() {
        setSelectedLocation(null);
    }

    public boolean hasSelectedLocation() {
        return selectedLocation != null;
    }

    public Color nextPlayer() {
        if(currentPlayer == ChessBoard.getChessColor3())
            thisplayer.setText("Player turn: VIOLET");
        else  thisplayer.setText("Player turn: RED");
        return currentPlayer = currentPlayer == ChessBoard.getChessColor3()? ChessBoard.getChessColor1() : ChessBoard.getChessColor3();
    }


    @Override
    public void onPlayerClickSquare(ChessBoardLocation location, SquareComponent component) throws InterruptedException {
        boolean judge = true;
        if (hasSelectedLocation()){
            int initialRow = getSelectedLocation().getRow();
            int initialCol = getSelectedLocation().getColumn();
            int finalRow = location.getRow();
            int finalCol = location.getColumn();
            if ((model.getChessPieceAt(getSelectedLocation()).getColor() == ChessBoard.getChessColor3())
                    && (camp[initialRow][initialCol] == 1)){
                judge = camp[finalRow][finalCol] == 1;
            }
            if ((model.getChessPieceAt(getSelectedLocation()).getColor() == ChessBoard.getChessColor1())
                    && (camp[initialRow][initialCol] == 3)){
                judge = camp[finalRow][finalCol] == 3;
            }
        }
        if (hasSelectedLocation() && model.isValidMove(getSelectedLocation(), location) && judge) {
            initialLocation.add(getSelectedLocation());
            finalLocation.add(location);
            i1 = i2; f1 = f2; i2 = selectedLocation; f2 = location;
            int count3 = 0; int count1 = 0;
            if (model.getCount() > 0) {
                ArrayList<ChessBoardLocation> jumpList = model.getJumpList();
                Thread t = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        for (int i = jumpList.size() - 1; i > 0; i --){
                            model.moveChessPiece(jumpList.get(i),jumpList.get(i - 1));
                            try {
                                Thread.sleep(500);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                });
                t.start();
            }
            else{
                model.moveChessPiece(selectedLocation, location);
            }
            resetSelectedLocation();
            resetCanMove();
            for (int i = 0; i < model.getDimension(); i++){
                for (int j = 0; j < model.getDimension(); j++){
                    if (model.getChessPieceAt(new ChessBoardLocation(i,j)) == null){
                        situation[i][j] = 0;
                    }else{
                        Color currentColor = model.getChessPieceAt(new ChessBoardLocation(i,j)).getColor();
                        situation[i][j] = (currentColor == ChessBoard.getChessColor3()) ? 3 : 1;
                    }
                    if ((situation[i][j] == 3) && (camp[i][j] == 1)) count3 ++;
                    if ((situation[i][j] == 1) && (camp[i][j] == 3)) count1 ++;
                }
            }
            nextPlayer();
            if ((GameController.this.isWinner() == 1) || (GameController.this.isWinner() == 3)) {
                JFrame jf = new JFrame();
                jf.setSize(300,100);
                if (GameController.this.isWinner() == 1) {
                    JLabel jl = new JLabel("VIOLET Victory!",JLabel.CENTER);
                    currentPlayer = ChessBoard.getChessColor1();
                    jf.add(jl);
                    victoryMusic vm = new victoryMusic();
                    vm.play();
                    thisplayer.setText("Game Over");
                }
                if (GameController.this.isWinner() == 3) {
                    JLabel jl = new JLabel("RED Victory!",JLabel.CENTER);
                    currentPlayer = ChessBoard.getChessColor3();
                    jf.add(jl);
                    victoryMusic vm = new victoryMusic();
                    vm.play();
                    thisplayer.setText("Game Over");
                }

                jf.setLocation(620,300);
                jf.setVisible(true);
            }
            else {
                ChessBoardLocation p = null,q = null;
                JFrame jf = new JFrame();
                jf.setSize(300,100);
                if (model.getChessPieceAt(location) != null){
                    if ((model.getChessPieceAt(location).getColor() == ChessBoard.getChessColor1()) && (count1 == 18)){
                        for (int i = 0; i < 16; i ++) {
                            for (int j = 0; j < 16; j ++){
                                if ((camp[i][j] == 3) && (situation[i][j] == 0)) p = new ChessBoardLocation(i,j);
                                if ((camp[i][j] == 0) && (situation[i][j] == 1)) q = new ChessBoardLocation(i,j);
                            }
                        }
                        if ((p != null) && (q != null) && (model.isValidMove(q,p))) {
                            JLabel jl = new JLabel("Violet is about to win!",JLabel.CENTER);
                            jf.add(jl);
                            jf.setLocation(620,300);
                            jf.setVisible(true);
                        }
                    }
                    if ((model.getChessPieceAt(location).getColor() == ChessBoard.getChessColor3()) && (count3 == 18)){
                        for (int i = 0; i < 16; i ++) {
                            for (int j = 0; j < 16; j ++){
                                if ((camp[i][j] == 1) && (situation[i][j] == 0)) p = new ChessBoardLocation(i,j);
                                if ((camp[i][j] == 0) && (situation[i][j] == 3)) q = new ChessBoardLocation(i,j);
                            }
                        }
                        if ((p != null) && (q != null) && (model.isValidMove(q,p))) {
                            JLabel jl = new JLabel("Red is about to win!",JLabel.CENTER);
                            jf.add(jl);
                            jf.setLocation(620,300);
                            jf.setVisible(true);
                        }
                    }
                }
            }
        }

    }

    public void playMovingSteps(){
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                model.placeInitialPieces2();
                for (int i = 0; i < initialLocation.size(); i ++){
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    model.moveChessPiece(initialLocation.get(i), finalLocation.get(i));
                }
            }
        });
        t.start();
    }

    public void undo(){
        if ((i1 != null) && (i2 != null) && (f1 != null) && (f2 != null)){
            model.moveChessPiece(f2,i2);
            model.moveChessPiece(f1,i1);
            i1 = null; i2 = null; f1 = null; f2 = null;
            resetSelectedLocation();
        }
    }

    @Override
    public void onPlayerClickChessPiece(ChessBoardLocation location, ChessComponent component) {
        ChessPiece piece = model.getChessPieceAt(location);
        if (piece.getColor() == currentPlayer && (!hasSelectedLocation() || location.equals(getSelectedLocation()))) {
            if (!hasSelectedLocation()) {
                setSelectedLocation(location);
                canMoveColor = model.getChessPieceAt(location).getColor();
                for (int i = 0; i < 16; i ++){
                    for (int j = 0; j < 16; j ++){
                        ChessBoardLocation theLocation = new ChessBoardLocation(i,j);
                        if (model.isValidMove(location,theLocation)){
                            boolean judge = true;
                            int initialRow = location.getRow();
                            int initialCol = location.getColumn();
                            if ((model.getChessPieceAt(location).getColor() == ChessBoard.getChessColor3())
                                    && (camp[initialRow][initialCol] == 1)){
                                judge = camp[i][j] == 1;
                            }
                            if ((model.getChessPieceAt(location).getColor() == ChessBoard.getChessColor1())
                                    && (camp[initialRow][initialCol] == 3)){
                                judge = camp[i][j] == 3;
                            }
                            if (judge) canMove[i][j] = true;
                        }
                    }
                }
            } else {
                resetSelectedLocation();
                resetCanMove();
            }
            component.setSelected(!component.isSelected());
            component.repaint();
        }
    }

    public int isWinner(){
        boolean Player1 = true;
        boolean Player3 = true;
        for (int row = 0; row < model.getDimension(); row++){
            for (int col = 0; col < model.getDimension(); col++){
                if (camp[row][col] == 1){
                    Player3 = false;
                    if (model.getChessPieceAt(new ChessBoardLocation(row,col)) != null) {
                        Color currentColor = model.getChessPieceAt(new ChessBoardLocation(row,col)).getColor();
                        Player3 = (currentColor == ChessBoard.getChessColor3());
                    }
                }
                if (!Player3) break;
            }
            if (!Player3) break;
        }
        for (int row = 0; row < model.getDimension(); row++){
            for (int col = 0; col < model.getDimension(); col++){
                if (camp[row][col] == 3) {
                    Player1 = false;
                    if (model.getChessPieceAt(new ChessBoardLocation(row,col)) != null) {
                        Color currentColor = model.getChessPieceAt(new ChessBoardLocation(row,col)).getColor();
                        Player1 = (currentColor == ChessBoard.getChessColor1());
                    }
                }
                if (!Player1) break;
            }
            if (!Player1) break;
        }
        if ((Player1) && (Player3)) return -1;
        if (Player1) return 1;
        if (Player3) return 3;
        return 0;
    }

    public int[][] getSituation() {
        return situation;
    }

    public Color getCanMoveColor() {
        return canMoveColor;
    }
}
