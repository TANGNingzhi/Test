package xyz.chengzi.halma;

import xyz.chengzi.halma.view.StartWindows;
import javax.swing.*;


public class Halma {

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {

            StartWindows S = new StartWindows();
            S.setVisible(true);

        });

    }

}