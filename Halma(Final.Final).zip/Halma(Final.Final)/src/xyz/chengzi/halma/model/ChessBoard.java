package xyz.chengzi.halma.model;

import xyz.chengzi.halma.listener.GameListener;
import xyz.chengzi.halma.listener.Listenable;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class ChessBoard implements Listenable<GameListener> {
    private List<GameListener> listenerList = new ArrayList<>();
    private Square[][] grid;
    private int dimension;
    private int count = 0;
    private static final Color CHESS_COLOR_1 = new Color(106, 90, 205);
    private static final Color CHESS_COLOR_2 = new Color(46, 139, 87);
    private static final Color CHESS_COLOR_3 = new Color(255, 106, 106);
    private static final Color CHESS_COLOR_4 = new Color(255, 185, 15);
    private int[][] situation = new int[dimension][dimension];
    private ArrayList<ChessBoardLocation> jumpList = new ArrayList<>();

    public static Color getChessColor1() {
        return CHESS_COLOR_1;
    }

    public static Color getChessColor2() { return CHESS_COLOR_2; }

    public static Color getChessColor3() {
        return CHESS_COLOR_3;
    }

    public static Color getChessColor4() {
        return CHESS_COLOR_4;
    }



    public ChessBoard(int dimension) {
        this.grid = new Square[dimension][dimension];
        this.dimension = dimension;

        initGrid();
    }

    private void initGrid() {
        for (int i = 0; i < dimension; i++) {
            for (int j = 0; j < dimension; j++) {
                grid[i][j] = new Square(new ChessBoardLocation(i, j));
            }
        }
    }

    public void placeInitialPieces2(int[][] situation){
        for (int i = 0; i < dimension; i++){
            for (int j = 0; j < dimension; j++){
                if (situation[i][j] == 1) grid[i][j].setPiece(new ChessPiece(CHESS_COLOR_1));
                else if (situation[i][j] == 2) grid[i][j].setPiece(new ChessPiece(CHESS_COLOR_2));
                else if (situation[i][j] == 3) grid[i][j].setPiece(new ChessPiece(CHESS_COLOR_3));
                else if (situation[i][j] == 4) grid[i][j].setPiece(new ChessPiece(CHESS_COLOR_4));
                else grid[i][j].setPiece(null);
            }
        }
        listenerList.forEach(listener -> listener.onChessBoardReload(this));
    }

    public void placeInitialPieces2() {
        for (int i = 0; i <dimension ; i++) {
            for (int j = 0; j <dimension ; j++) {
                grid[i][j].setPiece(null);
            }
        }
        for (int i = 0; i <= 5; i ++) {
            for (int j = 0; j <= 5 - i; j ++) {
                grid[i][j].setPiece(new ChessPiece(CHESS_COLOR_3));
                grid[dimension - i - 1][dimension - j - 1].setPiece(new ChessPiece(CHESS_COLOR_1));
            }
        }
        grid[0][5].setPiece(null);grid[5][0].setPiece(null);
        grid[dimension - 1][dimension - 6].setPiece(null);grid[dimension - 6][dimension - 1].setPiece(null);
        listenerList.forEach(listener -> listener.onChessBoardReload(this));
    }

    public void placeInitialPieces4(int[][] situation){
        for (int i = 0; i < dimension; i++){
            for (int j = 0; j < dimension; j++){
                if (situation[i][j] == 1) grid[i][j].setPiece(new ChessPiece(CHESS_COLOR_1));
                else if (situation[i][j] == 2) grid[i][j].setPiece(new ChessPiece(CHESS_COLOR_2));
                else if (situation[i][j] == 3) grid[i][j].setPiece(new ChessPiece(CHESS_COLOR_3));
                else if (situation[i][j] == 4) grid[i][j].setPiece(new ChessPiece(CHESS_COLOR_4));
                else grid[i][j].setPiece(null);
            }
        }
        listenerList.forEach(listener -> listener.onChessBoardReload(this));
    }

    public void placeInitialPieces4() {
        for (int i = 0; i <dimension ; i++) {
            for (int j = 0; j <dimension ; j++) {
                grid[i][j].setPiece(null);
            }
        }

        for (int i = 0; i <= 4; i ++) {
            for (int j = 0; j <= 4 - i; j ++) {
                grid[i][j].setPiece(new ChessPiece(CHESS_COLOR_3));
                grid[dimension - i - 1][dimension - j - 1].setPiece(new ChessPiece(CHESS_COLOR_1));
                grid[i][dimension - j - 1].setPiece(new ChessPiece(CHESS_COLOR_2));
                grid[dimension - i - 1][j].setPiece(new ChessPiece(CHESS_COLOR_4));
            }
        }
        grid[0][4].setPiece(null);grid[4][0].setPiece(null);
        grid[dimension - 1][dimension - 5].setPiece(null);grid[dimension - 5][dimension - 1].setPiece(null);
        grid[0][dimension - 5].setPiece(null);grid[4][dimension - 1].setPiece(null);
        grid[dimension - 1][4].setPiece(null);grid[dimension - 5][0].setPiece(null);
        listenerList.forEach(listener -> listener.onChessBoardReload(this));
    }



    public Square getGridAt(ChessBoardLocation location) {
        return grid[location.getRow()][location.getColumn()];
    }

    public ChessPiece getChessPieceAt(ChessBoardLocation location) {
        return getGridAt(location).getPiece();
    }

    public void setChessPieceAt(ChessBoardLocation location, ChessPiece piece) {
        getGridAt(location).setPiece(piece);
        listenerList.forEach(listener -> listener.onChessPiecePlace(location, piece));
    }

    public ChessPiece removeChessPieceAt(ChessBoardLocation location) {
        ChessPiece piece = getGridAt(location).getPiece();
        getGridAt(location).setPiece(null);
        listenerList.forEach(listener -> listener.onChessPieceRemove(location));
        return piece;
    }

    public void moveChessPiece(ChessBoardLocation src, ChessBoardLocation dest) {
        setChessPieceAt(dest, removeChessPieceAt(src));
    }

    public int getDimension() {
        return dimension;
    }

    public boolean isValidMove(ChessBoardLocation src, ChessBoardLocation dest) {
        resetJumpList();
        resetCount();
        return isAMove(src, dest) || isAJump(src, dest);
    }

    public boolean isAMove(ChessBoardLocation src, ChessBoardLocation dest){
        if (getChessPieceAt(src) == null || getChessPieceAt(dest) != null) {
            return false;
        }
        int srcRow = src.getRow(), srcCol = src.getColumn(), destRow = dest.getRow(), destCol = dest.getColumn();
        int rowDistance = destRow - srcRow, colDistance = destCol - srcCol;
        if (rowDistance != 0 && colDistance != 0 && Math.abs((double) rowDistance / colDistance) != 1.0) {
            return false;
        }
        return Math.abs(rowDistance) <= 1 && Math.abs(colDistance) <= 1;
    }


    public boolean isAJump(ChessBoardLocation src, ChessBoardLocation dest){
        boolean[][] judge;
        judge = new boolean[dimension][dimension];
        for (int i = 0; i < dimension; i ++) {
            for (int j = 0; j < dimension; j++) {
                ChessBoardLocation loc = new ChessBoardLocation(i, j);
                judge[i][j] = (getChessPieceAt(loc) == null);
            }
        }
        if (getChessPieceAt(src) == null || getChessPieceAt(dest) != null) {
            return false;
        }
        return midJudge(src, dest, judge);
    }

    public boolean midJudge(ChessBoardLocation src, ChessBoardLocation dest, boolean[][] judge){
        if (isAStepJump(src,dest)) {
            count = 0;
            jumpList.add(dest);
            jumpList.add(src);
            return true;
        }
        int srcRow = src.getRow(), srcCol = src.getColumn();
        for (int i = srcRow - 2; i <= srcRow + 2; i = i + 2){
            for (int j = srcCol - 2; j <= srcCol + 2; j = j + 2){
                if ((i >= 0) && (i < dimension) && (j >= 0) && (j < dimension)){
                    if ((judge[i][j]) && (isAStepJump(src, new ChessBoardLocation(i,j)))){
                        judge[i][j] = false;
                        if (midJudge(new ChessBoardLocation(i,j), dest, judge)){
                            count ++;
                            jumpList.add(src);
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    public boolean isAStepJump(ChessBoardLocation src, ChessBoardLocation dest){
        int srcRow = src.getRow(), srcCol = src.getColumn(), destRow = dest.getRow(), destCol = dest.getColumn();
        int rowDistance = destRow - srcRow, colDistance = destCol - srcCol;
        if (!(((Math.abs(rowDistance) == 2) || (rowDistance == 0))
                && ((Math.abs(colDistance) == 2) || (colDistance == 0)))) {
            return false;
        }
        int midRow = (srcRow + destRow) / 2, midCol = (srcCol + destCol) / 2;
        ChessBoardLocation mid = new ChessBoardLocation(midRow, midCol);
        return getChessPieceAt(mid) != null;
    }

    public ArrayList<ChessBoardLocation> getJumpList() {
        return jumpList;
    }

    public void resetJumpList(){
        this.jumpList.clear();
    }

    public int getCount() {
        return count;
    }


    public void resetCount(){
        this.count = 0;
    }

    @Override
    public void registerListener(GameListener listener) {
        listenerList.add(listener);
    }

    @Override
    public void unregisterListener(GameListener listener) {
        listenerList.remove(listener);
    }
}
