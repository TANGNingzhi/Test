package xyz.chengzi.halma.view;

import xyz.chengzi.halma.listener.GameListener;
import xyz.chengzi.halma.listener.InputListener;
import xyz.chengzi.halma.listener.Listenable;
import xyz.chengzi.halma.model.ChessBoard;
import xyz.chengzi.halma.model.ChessBoardLocation;
import xyz.chengzi.halma.model.ChessPiece;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

public class ChessBoardComponent extends JComponent implements Listenable<InputListener>, GameListener {
    private static final Color BOARD_COLOR_1 = new Color(255, 255, 255);
    private static final Color BOARD_COLOR_2 = new Color(190, 190, 190);
    private static final Color CAN_1 = new Color(96, 160, 190);
    private static final Color CAN_2 = new Color(106, 190, 150);
    private static final Color CAN_3 = new Color(255, 166, 166);
    private static final Color CAN_4 = new Color(255, 225, 120);
    private static final Color CHESS_COLOR_1 = new Color(106, 90, 205);
    private static final Color CHESS_COLOR_2 = new Color(46, 139, 87);
    private static final Color CHESS_COLOR_3 = new Color(255, 106, 106);
    private static final Color CHESS_COLOR_4 = new Color(255, 185, 15);

    private List<InputListener> listenerList = new ArrayList<>();
    private SquareComponent[][] gridComponents;
    private int dimension;
    private int gridSize;

    public ChessBoardComponent(int size, int dimension) {
        enableEvents(AWTEvent.MOUSE_EVENT_MASK);
        setLayout(null); // Use absolute layout
        setSize(size, size);

        this.gridComponents = new SquareComponent[dimension][dimension];
        this.dimension = dimension;
        this.gridSize = size / dimension;
        initGridComponents();
    }

    private void initGridComponents() {
        for (int row = 0; row < dimension; row++) {
            for (int col = 0; col < dimension; col++) {
                gridComponents[row][col] = new SquareComponent(gridSize,
                        (row + col) % 2 == 0 ? BOARD_COLOR_1 : BOARD_COLOR_2);
                gridComponents[row][col].setLocation(row * gridSize, col * gridSize);
                JLabel jl = new JLabel("YES");
                jl.setHorizontalAlignment(SwingConstants.CENTER);
                gridComponents[row][col].add(jl);
                add(gridComponents[row][col]);
            }
        }
    }

    public SquareComponent getGridAt(ChessBoardLocation location) {
        return gridComponents[location.getRow()][location.getColumn()];
    }

    public void setCanMoveComponents(boolean[][] canMove, Color color){
        for (int i = 0; i < 16; i++){
            for (int j = 0; j < 16; j++){
                if (canMove[i][j]){
                    ChessBoardLocation location = new ChessBoardLocation(i,j);
                    removeChessAtGrid(location);
                    if (color == ChessBoard.getChessColor1()) getGridAt(location).add(new CanMoveComponent(CAN_1));
                    if (color == ChessBoard.getChessColor2()) getGridAt(location).add(new CanMoveComponent(CAN_2));
                    if (color == ChessBoard.getChessColor3()) getGridAt(location).add(new CanMoveComponent(CAN_3));
                    if (color == ChessBoard.getChessColor4()) getGridAt(location).add(new CanMoveComponent(CAN_4));
                }
            }
        }
    }

    public void deleteCanMoveComponents(boolean[][] canMove){
        for (int i = 0; i < 16; i++){
            for (int j = 0; j < 16; j++){
                if (canMove[i][j]){
                    ChessBoardLocation location = new ChessBoardLocation(i,j);
                    getGridAt(location).removeAll();
                    getGridAt(location).revalidate();
                    repaint();
                }
            }
        }
    }

    public void setChessAtGrid(ChessBoardLocation location, Color color) {
        removeChessAtGrid(location);
        getGridAt(location).add(new ChessComponent(color));
    }

    public void removeChessAtGrid(ChessBoardLocation location) {
        // Note: re-validation is required after remove / removeAll
        getGridAt(location).removeAll();
        getGridAt(location).revalidate();
    }

    private ChessBoardLocation getLocationByPosition(int x, int y) {
        return new ChessBoardLocation(x / gridSize, y / gridSize);
    }

    @Override
    protected void processMouseEvent(MouseEvent e) {
        super.processMouseEvent(e);

        if (e.getID() == MouseEvent.MOUSE_PRESSED) {
            JComponent clickedComponent = (JComponent) getComponentAt(e.getX(), e.getY());
            ChessBoardLocation location = getLocationByPosition(e.getX(), e.getY());
            for (InputListener listener : listenerList) {
                if (clickedComponent.getComponentCount() == 0) {
                    try {
                        listener.onPlayerClickSquare(location, (SquareComponent) clickedComponent);
                    } catch (InterruptedException ex) {
                        ex.printStackTrace();
                    }
                } else {
                    listener.onPlayerClickChessPiece(location, (ChessComponent) clickedComponent.getComponent(0));
                }
            }
        }
    }

    @Override
    public void onChessPiecePlace(ChessBoardLocation location, ChessPiece piece) {
        setChessAtGrid(location, piece.getColor());
        repaint();
    }

    @Override
    public void onChessPieceRemove(ChessBoardLocation location) {
        removeChessAtGrid(location);
        repaint();
    }

    @Override
    public void onChessBoardReload(ChessBoard board) {
        for (int row = 0; row < board.getDimension(); row++) {
            for (int col = 0; col < board.getDimension(); col++) {
                ChessBoardLocation location = new ChessBoardLocation(row, col);
                ChessPiece piece = board.getChessPieceAt(location);
                if (piece != null) {
                    setChessAtGrid(location, piece.getColor());
                }
                else{
                    removeChessAtGrid(location);
                }
            }
        }
        repaint();
    }

    @Override
    public void registerListener(InputListener listener) {
        listenerList.add(listener);
    }

    @Override
    public void unregisterListener(InputListener listener) {
        listenerList.remove(listener);
    }
}
