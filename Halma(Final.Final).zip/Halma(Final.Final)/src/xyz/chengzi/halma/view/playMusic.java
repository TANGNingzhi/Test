package xyz.chengzi.halma.view;

import javax.swing.*;
import java.applet.AudioClip;
import java.net.MalformedURLException;
import java.net.URL;

public class playMusic {
        public static AudioClip loadSound(String filename) {
            URL url = null;
            try {
                url = new URL("file:" + filename);
            }
            catch (MalformedURLException e) {;}
            return JApplet.newAudioClip(url);
        }
        public void play() {
            AudioClip christmas = loadSound("背景音乐.wav");
            christmas.loop();
            christmas.play();

        }
    }
