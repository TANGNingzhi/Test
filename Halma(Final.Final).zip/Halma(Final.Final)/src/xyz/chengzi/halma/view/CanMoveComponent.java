package xyz.chengzi.halma.view;

import javax.swing.*;
import java.awt.*;

public class CanMoveComponent extends JComponent{
    Color color;

    public CanMoveComponent(Color color){
        this.color = color;
    }

    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        paintIcon(g);
    }

    private void paintIcon(Graphics g) {
        ((Graphics2D) g).setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setColor(color);

        int spacing = (int) (getWidth() * 0.05);
        g.fillOval(spacing, spacing, getWidth() - 2 * spacing, getHeight() - 2 * spacing);
    }

}
