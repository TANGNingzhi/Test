package xyz.chengzi.halma.view;

import xyz.chengzi.halma.controller.GameController;
import xyz.chengzi.halma.controller.GameController4;
import xyz.chengzi.halma.model.ChessBoard;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class GameFrame4 extends JFrame {
    public JMenuBar menuBar;
    public JMenu Menu = new JMenu("Menu");
    public JMenuItem
            Exit = new JMenuItem("Exit"),
            SaveGame = new JMenuItem("Save the game"),
            NewGame = new JMenuItem("New Game"),
            Undo =  new JMenuItem("Undo"),
            Hint = new JMenuItem("Hint"),
            EndHint = new JMenuItem("EndHint"),
            PlayMovingSteps = new JMenuItem("Play Moving Steps");


    Date now = new Date();

    public GameFrame4() {
        playMusic p = new playMusic();
        p.play();

        setTitle("Halma_Four Players");
        setSize(770, 870);
        setLocationRelativeTo(null); // Center the window
        //setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setLayout(null);

        JLabel statusLabel = new JLabel("-Four players are playing-");
        statusLabel.setLocation(0, 760);
        statusLabel.setSize(250, 20);
        add(statusLabel);

        Label time = new Label();
        time.setLocation(50, 780);
        time.setSize(230, 20);
        add(time);

        now.setHours(0);
        now.setMinutes(0);
        now.setSeconds(0);
        Timer timer = new Timer(1000, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                final Date now2 = new Date(now.getTime() + 1000);
                now = now2;
                SimpleDateFormat formatter = new SimpleDateFormat("HH:mm:ss");
                time.setText(formatter.format(now));
            }
        });
        timer.start();

        JButton button1 = new JButton("Pause");
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (timer.isRunning()) {
                    timer.stop();
                    hitplaymusic hp = new hitplaymusic();
                    hp.play();
                    JOptionPane.showMessageDialog(null, "Game has been paused!");
                    button1.setText("Start");
                } else {
                    timer.start();
                    hitplaymusic hp = new hitplaymusic();
                    hp.play();
                    JOptionPane.showMessageDialog(null, "Game has been started!");
                    button1.setText("Pause");
                }

            }
        });
        button1.setLocation(650, 760);
        button1.setSize(100, 20);
        add(button1);

        ChessBoardComponent chessBoardComponent = new ChessBoardComponent(760, 16);
        ChessBoard chessBoard = new ChessBoard(16);
        JLabel player = new JLabel();
        player.setLocation(300, 760);
        player.setSize(150, 40);
        add(player);
        GameController4 controller = new GameController4(chessBoardComponent, chessBoard);
        JDialog jd = new JDialog(GameFrame4.this);
        jd.setLocation(650, 760);
        JLabel jl = new JLabel();
        jl.setHorizontalAlignment(JLabel.CENTER);
        if ((controller.getCurrentPlayer().equals(ChessBoard.getChessColor3()))){
            player.setText("Player turn: RED");
            jl.setText("RED FIRST");
        }
        else if ((controller.getCurrentPlayer().equals(ChessBoard.getChessColor1()))){
            player.setText("Player turn: VIOLET");
            jl.setText("VIOLET FIRST");
        }
        else if ((controller.getCurrentPlayer().equals(ChessBoard.getChessColor2()))){
            player.setText("Player turn: GREEN");
            jl.setText("GREEN FIRST");
        }
        else if ((controller.getCurrentPlayer().equals(ChessBoard.getChessColor4()))){
            player.setText("Player turn: YELLOW");
            jl.setText("YELLOW FIRST");
        }
        jd.add(jl);
        jd.setSize(300, 100);
        jd.setLocation(620, 260);
        jd.setVisible(true);

        add(chessBoardComponent);

        controller.setThisplayer(player);

        SaveGame.addActionListener((e) -> {
            hitplaymusic hp = new hitplaymusic();
            hp.play();
            JOptionPane.showMessageDialog(this, "Game has been saved!");
            File file = new File("CurrentGame 4.txt");
            int[][] theCamp = controller.getSituation();
            String str;
            if (controller.getCurrentPlayer() == ChessBoard.getChessColor3()) str = "3";
            else if (controller.getCurrentPlayer() == ChessBoard.getChessColor1()) str = "1";
            else if (controller.getCurrentPlayer() == ChessBoard.getChessColor2()) str = "2";
            else str = "4";
            for (int i = 0; i < chessBoard.getDimension(); i++) {
                for (int j = 0; j < chessBoard.getDimension(); j++) {
                    str = str + theCamp[i][j];
                }
            }
            try {
                file.createNewFile();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            try {
                FileOutputStream out = new FileOutputStream(file);
                byte[] buy = str.getBytes();
                out.write(buy);
                out.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        });

        JButton button2 = new JButton("Restart Game");
        button2.setLocation(500,760);
        button2.setSize(150, 20);
        add(button2);

        button2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                controller.restartgame4();
                hitplaymusic hp = new hitplaymusic();
                hp.play();
                JDialog jd = new JDialog(GameFrame4.this);
                jd.setLocation(650, 260);
                JLabel jl = new JLabel();
                jl.setHorizontalAlignment(JLabel.CENTER);
                if ((controller.getCurrentPlayer().equals(ChessBoard.getChessColor3()))) {
                    jl.setText("RED FIRST");
                } else if ((controller.getCurrentPlayer().equals(ChessBoard.getChessColor1()))) {
                    jl.setText("VIOLET FIRST");
                } else if ((controller.getCurrentPlayer().equals(ChessBoard.getChessColor2()))) {
                    jl.setText("GREEN FIRST");
                } else if ((controller.getCurrentPlayer().equals(ChessBoard.getChessColor4()))) {
                    jl.setText("YELLOW FIRST");
                }
                jd.add(jl);
                jd.setSize(300, 100);
                jd.setVisible(true);
            }
        });

        menuBar = new JMenuBar();
        menuBar.add(Menu);
        setJMenuBar(menuBar);
        Menu.setMnemonic(KeyEvent.VK_A);
        Menu.add(SaveGame);
        Menu.add(NewGame);
        Menu.add(Undo);
        Menu.add(Hint);
        Menu.add(EndHint);
        Menu.add(PlayMovingSteps);
        Menu.add(Exit);

        PlayMovingSteps.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                controller.playMovingSteps();
            }
        });

        Hint.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                chessBoardComponent.setCanMoveComponents(controller.getCanMove(),controller.getCanMoveColor());
            }
        });

        EndHint.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                chessBoardComponent.deleteCanMoveComponents(controller.getCanMove());
            }
        });

        Undo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                controller.undo();
            }
        });


        NewGame.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                controller.restartgame4();
                hitplaymusic hp = new hitplaymusic();
                hp.play();
                JDialog jd = new JDialog(GameFrame4.this);
                jd.setLocation(650, 260);
                JLabel jl = new JLabel();
                jl.setHorizontalAlignment(JLabel.CENTER);
                if ((controller.getCurrentPlayer().equals(ChessBoard.getChessColor3()))) {
                    jl.setText("RED FIRST");
                } else if ((controller.getCurrentPlayer().equals(ChessBoard.getChessColor1()))) {
                    jl.setText("VIOLET FIRST");
                } else if ((controller.getCurrentPlayer().equals(ChessBoard.getChessColor2()))) {
                    jl.setText("GREEN FIRST");
                } else if ((controller.getCurrentPlayer().equals(ChessBoard.getChessColor4()))) {
                    jl.setText("YELLOW FIRST");
                }
                jd.add(jl);
                jd.setSize(300, 100);
                jd.setVisible(true);
            }
        });
    }

    public GameFrame4(File file1) {
        playMusic p = new playMusic();
        p.play();

        setTitle("Halma_Four Players");
        setSize(770, 870);
        setLocationRelativeTo(null);
        setLayout(null);

        JLabel statusLabel = new JLabel("-Four players are playing-");
        statusLabel.setLocation(0, 760);
        statusLabel.setSize(250, 20);
        add(statusLabel);

        Label time = new Label();
        time.setLocation(50, 780);
        time.setSize(200, 20);
        add(time);

        now.setHours(0);
        now.setMinutes(0);
        now.setSeconds(0);
        Timer timer = new Timer(1000, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                final Date now2 = new Date(now.getTime() + 1000);
                now = now2;
                SimpleDateFormat formatter = new SimpleDateFormat("HH:mm:ss");
                time.setText(formatter.format(now));
            }
        });
        timer.start();

        JButton button1 = new JButton("Pause");
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (timer.isRunning()) {
                    timer.stop();
                    hitplaymusic hp = new hitplaymusic();
                    hp.play();
                    JOptionPane.showMessageDialog(null, "Game has been paused!");
                    button1.setText("Start");
                } else {
                    timer.start();
                    hitplaymusic hp = new hitplaymusic();
                    hp.play();
                    JOptionPane.showMessageDialog(null, "Game has been started!");
                    button1.setText("Pause");
                }

            }
        });
        button1.setLocation(650, 760);
        button1.setSize(100, 20);
        add(button1);

        ChessBoardComponent chessBoardComponent = new ChessBoardComponent(760, 16);
        ChessBoard chessBoard = new ChessBoard(16);
        JLabel player = new JLabel();
        player.setLocation(250, 760);
        player.setSize(150, 40);
        add(player);
        int[][] situation = new int[16][16];
        int count = 1;
        String str = null;
        try {
            FileInputStream in = new FileInputStream(file1);
            byte[] byt = new byte[1024];
            int len = in.read(byt);
            str = new String(byt, 0, len);
            in.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        for (int i = 0; i < 16; i++) {
            for (int j = 0; j < 16; j++) {
                assert str != null;
                situation[i][j] = str.charAt(count) - 48;
                count++;
            }
        }
        GameController4 controller = new GameController4(chessBoardComponent, chessBoard, situation, str.charAt(0) - 48);
        JDialog jd = new JDialog(GameFrame4.this);
        jd.setLocation(650, 260);
        JLabel jl = new JLabel();
        jl.setHorizontalAlignment(JLabel.CENTER);
        if ((controller.getCurrentPlayer().equals(ChessBoard.getChessColor3()))) {
            player.setText("Player turn: RED");
            jl.setText("RED FIRST");
        } else if ((controller.getCurrentPlayer().equals(ChessBoard.getChessColor1()))) {
            player.setText("Player turn: VIOLET");
            jl.setText("VIOLET FIRST");
        } else if ((controller.getCurrentPlayer().equals(ChessBoard.getChessColor2()))) {
            player.setText("Player turn: GREEN");
            jl.setText("GREEN FIRST");
        } else if ((controller.getCurrentPlayer().equals(ChessBoard.getChessColor4()))) {
            player.setText("Player turn: YELLOW");
            jl.setText("YELLOW FIRST");
        }
        jd.add(jl);
        jd.setSize(300, 100);
        jd.setLocation(670, 260);

        JDialog jd0 = new JDialog(GameFrame4.this,"Error Check");
        JLabel jl0 = new JLabel();
        jl0.setHorizontalAlignment(JLabel.CENTER);
        jd0.setLocation(620,260);
        jd0.setSize(300, 100);
        jd0.add(jl0);

        int number3 = 0;
        int number2 = 0;
        int number4 = 0;
        int number1 = 0;
        for (int i = 0; i < 16; i ++) {
            for (int j = 0; j < 16; j ++){
                if (situation[i][j] == 3) number3 ++;
                if (situation[i][j] == 1) number1 ++;
                if (situation[i][j] == 2) number2 ++;
                if (situation[i][j] == 4) number4 ++;
            }
        }
        if (str.length() > 257) {
            jl0.setText("There exists chess out of chessboard! Error!");
            jd0.setVisible(true);
        }
        else if ((number1 == 0) || (number2 == 0) || (number3 == 0) || (number4 == 0)){
            jl0.setText("Players number incorrect! Error!");
            jd0.setVisible(true);
        }
        else if ((number3 != 13) || (number1 != 13) || (number2 != 13) || (number4 != 13)){
            jl0.setText("Chess pieces number incorrect! Error!");
            jd0.setVisible(true);
        }
        else if (controller.isWinner() != 0) {
            if ((controller.isWinner() == 1)) jl.setText("VIOLET Victory!");
            else if ((controller.isWinner() == 2)) jl.setText("GREEN Victory!");
            else if ((controller.isWinner() == 3)) jl.setText("RED Victory!");
            else jl.setText("YELLOW Victory!");
            jd.setVisible(true);
            player.setText("Game Over");
            victoryMusic vm=new victoryMusic();
            vm.play();
        }
        else jd.setVisible(true);

        add(chessBoardComponent);

        controller.setThisplayer(player);

        SaveGame.addActionListener((e) -> {
            hitplaymusic hp = new hitplaymusic();
            hp.play();
            JOptionPane.showMessageDialog(this, "Game has been saved!");
            File file = new File("CurrentGame 4.txt");
            int[][] theCamp = controller.getSituation();
            String str1;
            if (controller.getCurrentPlayer() == ChessBoard.getChessColor3()) str1 = "3";
            else if (controller.getCurrentPlayer() == ChessBoard.getChessColor1()) str1 = "1";
            else if (controller.getCurrentPlayer() == ChessBoard.getChessColor2()) str1 = "2";
            else str1 = "4";
            for (int i = 0; i < chessBoard.getDimension(); i++) {
                for (int j = 0; j < chessBoard.getDimension(); j++) {
                    str1 = str1 + theCamp[i][j];
                }
            }
            try {
                file.createNewFile();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            try {
                FileOutputStream out = new FileOutputStream(file);
                byte[] buy = str1.getBytes();
                out.write(buy);
                out.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        });

        JButton button2 = new JButton("Restart Game");
        button2.setLocation(500, 760);
        button2.setSize(150, 20);
        add(button2);

        button2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                controller.restartgame4();
                hitplaymusic hp = new hitplaymusic();
                hp.play();
                JDialog jd = new JDialog(GameFrame4.this);
                jd.setLocation(650, 260);
                JLabel jl = new JLabel();
                jl.setHorizontalAlignment(JLabel.CENTER);
                if ((controller.getCurrentPlayer().equals(ChessBoard.getChessColor3()))) {
                    jl.setText("RED FIRST");
                } else if ((controller.getCurrentPlayer().equals(ChessBoard.getChessColor1()))) {
                    jl.setText("VIOLET FIRST");
                } else if ((controller.getCurrentPlayer().equals(ChessBoard.getChessColor2()))) {
                    jl.setText("GREEN FIRST");
                } else if ((controller.getCurrentPlayer().equals(ChessBoard.getChessColor4()))) {
                    jl.setText("YELLOW FIRST");
                }
                jd.add(jl);
                jd.setSize(300, 100);
                jd.setVisible(true);
            }
        });

        menuBar = new JMenuBar();
        menuBar.add(Menu);
        setJMenuBar(menuBar);
        Menu.setMnemonic(KeyEvent.VK_A);
        Menu.add(SaveGame);
        Menu.add(NewGame);
        Menu.add(Undo);
        Menu.add(Hint);
        Menu.add(EndHint);
        Menu.add(Exit);

        Hint.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                chessBoardComponent.setCanMoveComponents(controller.getCanMove(),controller.getCanMoveColor());
            }
        });

        EndHint.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                chessBoardComponent.deleteCanMoveComponents(controller.getCanMove());
            }
        });

        Undo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                controller.undo();
            }
        });

        NewGame.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                controller.restartgame4();
                hitplaymusic hp = new hitplaymusic();
                hp.play();
                JDialog jd = new JDialog(GameFrame4.this);
                jd.setLocation(650, 760);
                JLabel jl = new JLabel();
                jl.setHorizontalAlignment(JLabel.CENTER);
                if ((controller.getCurrentPlayer().equals(ChessBoard.getChessColor3()))) {
                    jl.setText("RED FIRST");
                } else if ((controller.getCurrentPlayer().equals(ChessBoard.getChessColor1()))) {
                    jl.setText("VIOLET FIRST");
                } else if ((controller.getCurrentPlayer().equals(ChessBoard.getChessColor2()))) {
                    jl.setText("GREEN FIRST");
                } else if ((controller.getCurrentPlayer().equals(ChessBoard.getChessColor4()))) {
                    jl.setText("YELLOW FIRST");
                }
                jd.add(jl);
                jd.setSize(300, 100);
                jd.setVisible(true);
            }
        });
    }
}

