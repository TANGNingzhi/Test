package xyz.chengzi.halma.view;

import xyz.chengzi.halma.Halma;
import xyz.chengzi.halma.controller.GameController;
import xyz.chengzi.halma.controller.GameController4;
import xyz.chengzi.halma.controller.PlayWithMachine;
import xyz.chengzi.halma.model.ChessBoard;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MachineGameFrame extends JFrame {
    public JMenuBar menuBar;
    public JMenu Menu = new JMenu("Menu");
    public JMenuItem
            Exit = new JMenuItem("Exit"),
            SaveGame = new JMenuItem("Save the game"),
            NewGame = new JMenuItem("New Game"),
            Undo = new JMenuItem("Undo"),
            Hint = new JMenuItem("Hint"),
            EndHint = new JMenuItem("EndHint");


    Date now = new Date();

    public MachineGameFrame() {
        playMusic p = new playMusic();
        p.play();

        setTitle("Halma_Two Players");
        setSize(770, 870);
        setLocationRelativeTo(null); // Center the window
        //setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setLayout(null);

        JLabel statusLabel = new JLabel("-Two players are playing-");
        statusLabel.setLocation(0, 760);
        statusLabel.setSize(250, 20);
        add(statusLabel);

        JLabel time = new JLabel();
        time.setLocation(50, 780);
        time.setSize(230, 20);
        add(time);

        now.setHours(0);
        now.setMinutes(0);
        now.setSeconds(0);
        Timer timer = new Timer(1000, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                final Date now2 = new Date(now.getTime() + 1000);
                now = now2;
                SimpleDateFormat formatter = new SimpleDateFormat("HH:mm:ss");
                time.setText(formatter.format(now));
            }
        });
        timer.start();

        JButton button1 = new JButton("Pause");
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (timer.isRunning()) {
                    timer.stop();
                    hitplaymusic hp = new hitplaymusic();
                    hp.play();
                    JOptionPane.showMessageDialog(null, "Game has been paused!");
                    button1.setText("Start");
                } else {
                    timer.start();
                    hitplaymusic hp = new hitplaymusic();
                    hp.play();
                    JOptionPane.showMessageDialog(null, "Game has been started!");
                    button1.setText("Pause");
                }

            }
        });
        button1.setLocation(650, 760);
        button1.setSize(100, 20);
        add(button1);

        ChessBoardComponent chessBoardComponent = new ChessBoardComponent(760, 16);
        ChessBoard chessBoard = new ChessBoard(16);
        JLabel player = new JLabel();
        player.setLocation(250, 760);
        player.setSize(150, 40);
        add(player);
        PlayWithMachine controller = new PlayWithMachine(chessBoardComponent, chessBoard);
        player.setText("Player turn：" + (controller.getCurrentPlayer().equals(ChessBoard.getChessColor3()) ? "RED" : "VIOLET"));
        JDialog jd = new JDialog(MachineGameFrame.this);
        jd.setLocation(650, 760);
        JLabel jl = new JLabel((controller.getCurrentPlayer().equals(ChessBoard.getChessColor3()) ? "RED " : "VIOLET ") + "FIRST",
                JLabel.CENTER);
        jd.add(jl);
        jd.setSize(300, 100);
        jd.setLocation(620, 260);
        jd.setVisible(true);

        add(chessBoardComponent);

        controller.setThisplayer(player);

        SaveGame.addActionListener((e) -> {
            hitplaymusic hp = new hitplaymusic();
            hp.play();
            JOptionPane.showMessageDialog(this, "Game has been saved!");
            File file = new File("CurrentGame 2.txt");
            int[][] theCamp = controller.getSituation();
            String str;
            if (controller.getCurrentPlayer() == ChessBoard.getChessColor3()) str = "3";
            else str = "1";
            for (int i = 0; i < chessBoard.getDimension(); i++) {
                for (int j = 0; j < chessBoard.getDimension(); j++) {
                    str = str + theCamp[i][j];
                }
            }
            try {
                file.createNewFile();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            try {
                FileOutputStream out = new FileOutputStream(file);
                byte[] buy = str.getBytes();
                out.write(buy);
                out.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        });


        JButton button2 = new JButton("Restart Game");
        button2.setLocation(500, 760);
        button2.setSize(150, 20);
        add(button2);

        button2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                controller.reStartGame2();
                hitplaymusic hp = new hitplaymusic();
                hp.play();
                JDialog jd = new JDialog(MachineGameFrame.this);
                jd.setLocation(650, 760);
                JLabel jl = new JLabel((controller.getCurrentPlayer().equals(ChessBoard.getChessColor3()) ? "RED " : "VIOLET ") + " FIRST",
                        JLabel.CENTER);
                jd.add(jl);
                jd.setSize(300, 100);
                jd.setLocation(620, 260);
                jd.setVisible(true);
            }
        });

        menuBar = new JMenuBar();
        menuBar.add(Menu);
        setJMenuBar(menuBar);
        Menu.setMnemonic(KeyEvent.VK_A);
        Menu.add(SaveGame);
        Menu.add(NewGame);
        Menu.add(Undo);
        Menu.add(Hint);
        Menu.add(EndHint);
        Menu.add(Exit);

        Hint.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                chessBoardComponent.setCanMoveComponents(controller.getCanMove(),controller.getCanMoveColor());
            }
        });

        EndHint.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                chessBoardComponent.deleteCanMoveComponents(controller.getCanMove());
            }
        });


        Undo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                controller.undo();
            }
        });


        NewGame.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                controller.reStartGame2();
                hitplaymusic hp = new hitplaymusic();
                hp.play();
                JDialog jd = new JDialog(MachineGameFrame.this);
                jd.setLocation(650, 760);
                JLabel jl = new JLabel((controller.getCurrentPlayer().equals(ChessBoard.getChessColor3()) ? "RED " : "VIOLET ") + " FIRST",
                        JLabel.CENTER);
                jd.add(jl);
                jd.setSize(300, 100);
                jd.setLocation(620, 260);
                jd.setVisible(true);
            }
        });

    }


}
