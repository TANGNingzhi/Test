package xyz.chengzi.halma.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.*;

public class StartWindows extends JFrame {

    public ImageIcon background = new ImageIcon("Halma图.png");
    public JMenuBar menuBar;
    public JMenu Menu = new JMenu("Menu"),
            TwoPlayer = new JMenu("Two players"),
            FourPlayer = new JMenu("Four players"),
            NewGame = new JMenu("New Game"),
            OpenGame_2 = new JMenu("Open the game"),
            OpenGame_4 = new JMenu("Open the game");
    public JMenuItem two_players = new JMenuItem("Two players"),
            four_players = new JMenuItem("Four players"),
            Exit = new JMenuItem("Exit"),
            RestartLastGame_2 = new JMenuItem("Restart Last Game"),
            RestartLastGame_4 = new JMenuItem("Restart Last Game"),
            NewGame_2 = new JMenuItem("New game"),
            NewGame_4 = new JMenuItem("New game"),
            Machine = new JMenuItem("Human vs. Machine"),
            Game1_2 = new JMenuItem("Game 1"),
            Game2_2 = new JMenuItem("Game 2"),
            Game3_2 = new JMenuItem("Game 3"),
            Game4_2 = new JMenuItem("Game 4"),
            Game5_2 = new JMenuItem("Game 5"),
            Game1_4 = new JMenuItem("Game 1"),
            Game2_4 = new JMenuItem("Game 2"),
            Game3_4 = new JMenuItem("Game 3"),
            Game4_4 = new JMenuItem("Game 4"),
            Game5_4 = new JMenuItem("Game 5");

    public StartWindows() {
        playMusic p = new playMusic();
        p.play();

        setTitle("Halma");
        setSize(770, 810);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setLayout(null);

        JPanel titlePanel = new JPanel();
        JLabel titleLabel = new JLabel();
        titlePanel.setBounds(0, 0, 776, 810);
        background.setImage(background.getImage().getScaledInstance(titlePanel.getWidth(), titlePanel.getHeight(), Image.SCALE_DEFAULT));//设置图像大小
        titleLabel.setIcon(background);
        titlePanel.add(titleLabel);
        this.add(titlePanel, BorderLayout.NORTH);

        menuBar = new JMenuBar();
        menuBar.add(Menu);
        setJMenuBar(menuBar);
        Menu.setMnemonic(KeyEvent.VK_A);
        Menu.add(TwoPlayer);
        Menu.add(FourPlayer);
        Menu.add(Machine);
        Menu.add(Exit);

        NewGame.add(two_players);
        NewGame.add(four_players);
        TwoPlayer.add(NewGame_2);
        TwoPlayer.add(RestartLastGame_2);
        TwoPlayer.add(OpenGame_2);
        FourPlayer.add(NewGame_4);
        FourPlayer.add(RestartLastGame_4);
        FourPlayer.add(OpenGame_4);
        OpenGame_2.add(Game1_2);
        OpenGame_2.add(Game2_2);
        OpenGame_2.add(Game3_2);
        OpenGame_2.add(Game4_2);
        OpenGame_2.add(Game5_2);
        OpenGame_4.add(Game1_4);
        OpenGame_4.add(Game2_4);
        OpenGame_4.add(Game3_4);
        OpenGame_4.add(Game4_4);
        OpenGame_4.add(Game5_4);

        Exit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                System.exit(0);
            }
        });

        Game1_2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GameFrame2 mainFrame = new GameFrame2(new File("2Game 1.txt"));
                mainFrame.setVisible(true);
            }
        });

        Game2_2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GameFrame2 mainFrame = new GameFrame2(new File("2Game 2.txt"));
                mainFrame.setVisible(true);
            }
        });

        Game3_2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GameFrame2 mainFrame = new GameFrame2(new File("2Game 3.txt"));
                mainFrame.setVisible(true);
            }
        });

        Game4_2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GameFrame2 mainFrame = new GameFrame2(new File("2Game 4.txt"));
                mainFrame.setVisible(true);
            }
        });

        Game5_2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GameFrame2 mainFrame = new GameFrame2(new File("2Game 5.txt"));
                mainFrame.setVisible(true);
            }
        });

        Game1_4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GameFrame4 mainFrame = new GameFrame4(new File("4Game 1.txt"));
                mainFrame.setVisible(true);
            }
        });

        Game2_4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GameFrame4 mainFrame = new GameFrame4(new File("4Game 2.txt"));
                mainFrame.setVisible(true);
            }
        });

        Game3_4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GameFrame4 mainFrame = new GameFrame4(new File("4Game 3.txt"));
                mainFrame.setVisible(true);
            }
        });

        Game4_4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GameFrame4 mainFrame = new GameFrame4(new File("4Game 4.txt"));
                mainFrame.setVisible(true);
            }
        });

        Game5_4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GameFrame4 mainFrame = new GameFrame4(new File("4Game 5.txt"));
                mainFrame.setVisible(true);
            }
        });

        RestartLastGame_2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GameFrame2 mainFrame = new GameFrame2(new File("CurrentGame 2.txt"));
                mainFrame.setVisible(true);
            }
        });

        RestartLastGame_4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GameFrame4 mainFrame = new GameFrame4(new File("CurrentGame 4.txt"));
                mainFrame.setVisible(true);
            }
        });

        NewGame_2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GameFrame2 mainFrame = new GameFrame2();
                mainFrame.setVisible(true);

            }
        });
        NewGame_4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                GameFrame4 mainFrame = new GameFrame4();
                mainFrame.setVisible(true);
            }
        });

        Machine.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                MachineGameFrame mainFrame = new MachineGameFrame();
                mainFrame.setVisible(true);
            }
        });

    }
}
